package dev.msameer.vaw.api

import net.minecraft.world.entity.npc.villager.Villager
import net.minecraft.world.item.ItemStack

/**
 * Which food a villager eats (Technical Reference §23, #80), for an extension whose villagers are not
 * all alike at table: with MCA, a vegetarian eats no meat or fish. Without a provider every villager
 * eats any food. Villagers after Work asks it before a cook puts food on a diner's side, before a diner
 * takes a piece, and before a villager eats what it carries or picks up.
 */
public fun interface DietProvider {
    /** Whether [villager] eats [food], or `null` to leave it to the default, which eats any food. */
    public fun eats(villager: Villager, food: ItemStack): Boolean?
}
