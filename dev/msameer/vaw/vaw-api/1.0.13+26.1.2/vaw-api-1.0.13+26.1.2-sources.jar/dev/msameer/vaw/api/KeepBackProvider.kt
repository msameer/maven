package dev.msameer.vaw.api

import net.minecraft.world.entity.npc.villager.Villager
import net.minecraft.world.item.Item
import net.minecraft.world.item.ItemStack

/**
 * Holds back part of what a villager would take to storage (Technical Reference §6.3, §23).
 * Registered by Villagers after Work, whose cooks keep an evening share of their food.
 *
 * Only storage gives way to it: the core serves every order before it asks, so a customer never
 * goes without what a villager is keeping back.
 */
public fun interface KeepBackProvider {
    /** How many of [item] [villager] keeps back from storage, or 0 for none. */
    public fun keepsBack(villager: Villager, item: Item): Int

    /**
     * Whether [villager] takes [stack] to storage on its trip at the end of the shift although its job
     * would keep it, less what [keepsBack] holds back (§6.3, §23). The job's tools never go, whatever
     * this says. Villagers after Work has its cooks store all but their dinner and every other worker
     * its food. By default, nothing more goes than the job lets go.
     */
    public fun storesAtShiftEnd(villager: Villager, stack: ItemStack): Boolean = false
}
