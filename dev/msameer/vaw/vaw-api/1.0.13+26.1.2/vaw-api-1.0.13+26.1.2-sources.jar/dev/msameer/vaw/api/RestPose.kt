package dev.msameer.vaw.api

/**
 * How a villager rests after work when a vanilla villager model cannot show it (Technical Reference
 * §4.1, §23). Set by Villagers after Work and drawn by the client jar.
 */
public enum class RestPose {
    /** Seated upright on a cushion or a chair, legs bent. */
    SITTING,

    /** Seated on a cushion or a chair, leaning back on its hands, legs stretched out in front. */
    LEANING,

    /**
     * Lying back across two cushions, hands behind its head. The lying itself is vanilla's sleeping
     * pose, which every client draws; this is for the arms, and to settle the body across both.
     */
    LYING,
}
