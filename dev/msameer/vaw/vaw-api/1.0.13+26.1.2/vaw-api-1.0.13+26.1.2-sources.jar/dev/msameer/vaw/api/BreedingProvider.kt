package dev.msameer.vaw.api

import net.minecraft.server.level.ServerLevel
import net.minecraft.world.entity.npc.villager.Villager

/**
 * Breeds a pair of villagers at bedtime whose kind breeds by rules of its own (Technical Reference
 * §23, §16.1). Villagers after Work breeds vanilla villagers itself and asks the registered provider
 * about any other pair: with MCA, a married couple starts a pregnancy.
 *
 * Villagers after Work has already checked its own conditions when it asks: both are grown up, off
 * their cooldown and well fed, and the roll has come up.
 */
public fun interface BreedingProvider {
    /** Breeds [first] and [second] if they are this provider's to breed. */
    public fun breed(level: ServerLevel, first: Villager, second: Villager): Breeding
}

/** What a [BreedingProvider] did with a pair. */
public enum class Breeding {
    /** Neither villager is this provider's kind; Villagers after Work breeds them as vanilla villagers. */
    NOT_MINE,

    /** The pair is this provider's and may not breed, so neither is. */
    REFUSED,

    /** The pair is this provider's and a child is on its way, by the provider's own rules. */
    CONCEIVED,
}
