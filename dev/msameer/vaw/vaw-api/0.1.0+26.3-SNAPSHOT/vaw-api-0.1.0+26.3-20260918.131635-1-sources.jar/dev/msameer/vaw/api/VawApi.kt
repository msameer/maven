package dev.msameer.vaw.api

/** Where extensions plug into Villagers at Work (Technical Reference §1.5). */
public object VawApi {
    /** The namespace of every id this mod owns. */
    public const val NAMESPACE: String = "vaw"

    @Volatile
    private var guard: GuardProvider? = null

    @Volatile
    private var brain: VillagerBrainHook? = null

    /** The registered guard provider, or `null` when no guard extension is installed. */
    public val guardProvider: GuardProvider? get() = guard

    /** The core's behaviour installer, for extensions that rebuild a villager's brain (§16.1). */
    public val brainHook: VillagerBrainHook? get() = brain

    /**
     * Registers the guard provider. Its presence switches on armories and the guard-only makers
     * (§12.3). Call it during mod initialization.
     */
    public fun registerGuardProvider(provider: GuardProvider) {
        synchronized(this) {
            val existing = guard
            check(existing == null) { "a guard provider is already registered: ${existing?.id}" }
            guard = provider
        }
    }

    /** Registered by the core jar. Extensions call [brainHook], they do not register one. */
    public fun registerBrainHook(hook: VillagerBrainHook) {
        synchronized(this) {
            check(brain == null) { "a villager brain hook is already registered" }
            brain = hook
        }
    }
}
