package dev.msameer.vaw.api

import net.minecraft.world.entity.npc.villager.Villager

/**
 * Installs Villagers at Work behaviours into a villager's brain. The core installs them into
 * vanilla villagers itself; an extension whose villagers rebuild their brain without calling the
 * vanilla code, as MCA does, calls this after the rebuild (Technical Reference §16.1).
 */
public fun interface VillagerBrainHook {
    public fun install(villager: Villager)
}
