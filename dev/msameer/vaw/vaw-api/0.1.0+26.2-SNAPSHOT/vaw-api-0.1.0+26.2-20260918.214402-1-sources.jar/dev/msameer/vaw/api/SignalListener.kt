package dev.msameer.vaw.api

import net.minecraft.world.entity.npc.villager.Villager
import net.minecraft.world.item.Item

/** Why a villager cannot work (Technical Reference §8.2). */
public enum class BlockCause {
    /** Its shelf binding is ambiguous or shared. */
    SHELF,

    /** Its armor stand is ambiguous or shared. */
    ARMOR_STAND,

    /** An armor maker has no armory while guards exist. */
    ARMORY,

    /** A fisherman has no water to fish. */
    WATER,

    /** Village storage is full or out of reach. */
    STORAGE_FULL,

    /** One mandatory item is missing from its shelf. */
    MISSING_ITEM,

    /** More than one mandatory item is missing, so no single one is named. */
    SEVERAL_ITEMS,
}

/** A blocked villager's state: the cause, and the item the error icon shows, `null` for [BlockCause.SEVERAL_ITEMS]. */
public data class Blocked(val cause: BlockCause, val item: Item?)

/**
 * Told when a villager's blocked state changes, for extensions that signal it their own way, such as
 * MCA villagers speaking (§8.3). Called on the server thread, **only on a change**, never repeatedly
 * while nothing changes. A villager counts as blocked only during working hours, as the error icon
 * does (§2.2), so work starting while it is blocked is a change and work ending clears it.
 */
public fun interface SignalListener {
    /** [villager] is now [blocked], or works again when it is `null`. */
    public fun onBlockedChanged(villager: Villager, blocked: Blocked?)
}
