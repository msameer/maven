package dev.msameer.vaw.api

import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry
import net.fabricmc.fabric.api.attachment.v1.AttachmentSyncPredicate
import net.fabricmc.fabric.api.attachment.v1.AttachmentType
import net.minecraft.core.BlockPos
import net.minecraft.network.codec.ByteBufCodecs
import net.minecraft.network.codec.StreamCodec
import net.minecraft.resources.Identifier
import net.minecraft.world.item.ItemStack

/**
 * Data attachment types shared by the core and client jars (Technical Reference §4.1). Both jars
 * nest this api mod, so each type is registered under the same id on the server and the client.
 */
public object VawAttachments {
    /**
     * The tool a villager is working with: "I am using this". Never the equipment slot (§2.2).
     * Synced, so the optional client jar can draw it; vanilla clients never receive it.
     */
    public val WORKING_TOOL: AttachmentType<ItemStack> =
        AttachmentRegistry.create(Identifier.fromNamespaceAndPath(VawApi.NAMESPACE, "working_tool")) {
                builder: AttachmentRegistry.Builder<ItemStack> ->
            builder.persistent(ItemStack.OPTIONAL_CODEC)
                .syncWith(ItemStack.OPTIONAL_STREAM_CODEC, AttachmentSyncPredicate.all())
        }

    /**
     * What a villager holds in place of its working tool: the item it is taking to a shelf. Drawn
     * instead of [WORKING_TOOL] while present, and never the equipment slot either (§2.2). Only a
     * picture of what the villager carries, since the items themselves stay in its inventory, so it
     * is transient; synced like the working tool.
     */
    public val HELD_ITEM: AttachmentType<ItemStack> =
        AttachmentRegistry.create(Identifier.fromNamespaceAndPath(VawApi.NAMESPACE, "held_item")) {
                builder: AttachmentRegistry.Builder<ItemStack> ->
            builder.syncWith(ItemStack.OPTIONAL_STREAM_CODEC, AttachmentSyncPredicate.all())
        }

    /**
     * What a villager is drinking right now (§2.2, §11.11): a third channel, never [WORKING_TOOL],
     * whose stow, deposit and death-drop machinery a potion must not meet, and never [HELD_ITEM],
     * which is a picture of a delivery. Drawn before both while present. Transient, since a drink is
     * over in a couple of seconds and an unload mid-drink simply loses it; synced like the others.
     */
    public val HELD_CONSUMABLE: AttachmentType<ItemStack> =
        AttachmentRegistry.create(Identifier.fromNamespaceAndPath(VawApi.NAMESPACE, "held_consumable")) {
                builder: AttachmentRegistry.Builder<ItemStack> ->
            builder.syncWith(ItemStack.OPTIONAL_STREAM_CODEC, AttachmentSyncPredicate.all())
        }

    /**
     * How a villager rests after work, for a pose no vanilla villager model has (§4.1, §23): set by
     * Villagers after Work, drawn by the client jar. Transient, since it only describes what the
     * villager is doing this moment; synced like the others.
     */
    public val REST_POSE: AttachmentType<RestPose> =
        AttachmentRegistry.create(Identifier.fromNamespaceAndPath(VawApi.NAMESPACE, "rest_pose")) {
                builder: AttachmentRegistry.Builder<RestPose> ->
            builder.syncWith(
                ByteBufCodecs.VAR_INT.map({ RestPose.entries[it] }, { it.ordinal }),
                AttachmentSyncPredicate.all(),
            )
        }

    /**
     * A fisherman's line while it fishes (§2.5, §11.9): where its bobber floats and when the catch
     * lands, for the client jar to draw the cast line and the bobber. Transient, since it describes
     * this cast alone; synced like the others.
     */
    public val FISHING_LINE: AttachmentType<FishingLine> =
        AttachmentRegistry.create(Identifier.fromNamespaceAndPath(VawApi.NAMESPACE, "fishing_line")) {
                builder: AttachmentRegistry.Builder<FishingLine> ->
            builder.syncWith(
                StreamCodec.composite(BlockPos.STREAM_CODEC, FishingLine::water, ByteBufCodecs.VAR_LONG, FishingLine::bite, ::FishingLine),
                AttachmentSyncPredicate.all(),
            )
        }

    /** Touching this object registers every type. Called during mod initialization on both sides. */
    internal fun init() {
        check(WORKING_TOOL.identifier().namespace == VawApi.NAMESPACE)
        check(HELD_ITEM.identifier().namespace == VawApi.NAMESPACE)
        check(HELD_CONSUMABLE.identifier().namespace == VawApi.NAMESPACE)
        check(REST_POSE.identifier().namespace == VawApi.NAMESPACE)
        check(FISHING_LINE.identifier().namespace == VawApi.NAMESPACE)
    }
}
