package dev.msameer.vaw.api

import net.minecraft.world.entity.npc.villager.Villager
import net.minecraft.world.item.ItemStack

/**
 * Decides what a villager keeps for itself, and so never delivers or deposits (Technical Reference
 * §6.3, §16.1). Registered by an extension whose villagers use their inventory differently from
 * vanilla's: MCA villagers breed by MCA's own rules, so they keep no food, only seed.
 */
public fun interface ReserveProvider {
    /**
     * Whether [villager] keeps [stack], or `null` to leave it to the core's default, the
     * `vaw:villager_reserve` item tag. A job with a reserve rule of its own, such as the farmer's
     * (§11.1), never asks.
     */
    public fun reserves(villager: Villager, stack: ItemStack): Boolean?
}
