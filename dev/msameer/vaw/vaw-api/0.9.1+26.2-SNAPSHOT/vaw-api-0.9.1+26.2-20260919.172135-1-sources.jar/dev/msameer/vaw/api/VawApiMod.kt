package dev.msameer.vaw.api

import net.fabricmc.api.ModInitializer

internal object VawApiMod : ModInitializer {
    override fun onInitialize() {
        VawAttachments.init()
    }
}
