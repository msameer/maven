package dev.msameer.vaw.api

import net.minecraft.world.entity.npc.villager.Villager
import java.util.UUID

/**
 * Says whose errands a child runs (Technical Reference §16.1). Vanilla villagers remember no
 * parents, so without a provider a child runs errands for any working villager near it. An extension
 * whose villagers have families registers one to keep a child's errands within its family: with MCA,
 * a child runs errands only for its parents.
 */
public fun interface FamilyProvider {
    /**
     * The villagers [child] runs errands for, by UUID, or `null` to leave it to the core's default of
     * any working villager nearby. An empty set means nobody: an orphan runs no errands.
     */
    public fun parents(child: Villager): Set<UUID>?
}
