package dev.msameer.vaw.api

import net.minecraft.world.entity.EntityType
import net.minecraft.world.entity.npc.villager.Villager

/** Where extensions plug into Villagers at Work (Technical Reference §1.5). */
public object VawApi {
    /** The namespace of every id this mod owns. */
    public const val NAMESPACE: String = "vaw"

    @Volatile
    private var guard: GuardProvider? = null

    @Volatile
    private var reserve: ReserveProvider? = null

    @Volatile
    private var armories: ArmoryAccess? = null

    @Volatile
    private var deliveries: Deliveries? = null

    @Volatile
    private var signals: SignalListener? = null

    @Volatile
    private var family: FamilyProvider? = null

    @Volatile
    private var iconTypes: Set<EntityType<out Villager>> = emptySet()

    /** The registered guard provider, or `null` when no guard extension is installed. */
    public val guardProvider: GuardProvider? get() = guard

    /** Village armories, for a guard extension (§12.2). Registered by the core jar. */
    public val armoryAccess: ArmoryAccess? get() = armories

    /** Shelf orders, for villagers the core does not drive (§16.1). Registered by the core jar. */
    public val delivery: Deliveries? get() = deliveries

    /** The registered signal listener, or `null` when no extension signals blocked villagers itself (§8.3). */
    public val signalListener: SignalListener? get() = signals

    /**
     * Villager types besides vanilla's that show the error icon (§2.2). The core draws it only for
     * `minecraft:villager` unless an extension adds its own types here.
     */
    public val errorIconTypes: Set<EntityType<out Villager>> get() = iconTypes

    /** The registered reserve provider, or `null` when every villager keeps the default reserve (§16.1). */
    public val reserveProvider: ReserveProvider? get() = reserve

    /** The registered family provider, or `null` when a child runs errands for anyone nearby (§16.1). */
    public val familyProvider: FamilyProvider? get() = family

    /**
     * Registers the guard provider. Its presence switches on armories and the guard-only makers
     * (§12.3). Call it during mod initialization.
     */
    public fun registerGuardProvider(provider: GuardProvider) {
        synchronized(this) {
            val existing = guard
            check(existing == null) { "a guard provider is already registered: ${existing?.id}" }
            guard = provider
        }
    }

    /** Registers the reserve provider (§16.1). Call it during mod initialization. */
    public fun registerReserveProvider(provider: ReserveProvider) {
        synchronized(this) {
            check(reserve == null) { "a reserve provider is already registered" }
            reserve = provider
        }
    }

    /** Registers the family provider (§16.1). Call it during mod initialization. */
    public fun registerFamilyProvider(provider: FamilyProvider) {
        synchronized(this) {
            check(family == null) { "a family provider is already registered" }
            family = provider
        }
    }

    /** Registered by the core jar. Extensions read [armoryAccess], they do not register one. */
    public fun registerArmoryAccess(access: ArmoryAccess) {
        synchronized(this) {
            check(armories == null) { "armory access is already registered" }
            armories = access
        }
    }

    /** Registered by the core jar. Extensions read [delivery], they do not register one. */
    public fun registerDeliveries(orders: Deliveries) {
        synchronized(this) {
            check(deliveries == null) { "deliveries are already registered" }
            deliveries = orders
        }
    }

    /** Registers the signal listener (§8.3). Call it during mod initialization. */
    public fun registerSignalListener(listener: SignalListener) {
        synchronized(this) {
            check(signals == null) { "a signal listener is already registered" }
            signals = listener
        }
    }

    /** Has the core show the error icon on villagers of [type] too (§2.2). Call it during mod initialization. */
    public fun showErrorIconsFor(type: EntityType<out Villager>) {
        synchronized(this) { iconTypes = iconTypes + type }
    }
}
