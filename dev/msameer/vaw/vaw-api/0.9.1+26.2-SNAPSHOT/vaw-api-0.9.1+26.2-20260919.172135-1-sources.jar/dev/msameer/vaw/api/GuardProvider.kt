package dev.msameer.vaw.api

/**
 * Registered by a guard-mod extension. The core never detects guard mods itself; it learns that
 * guards exist only through this registration (Technical Reference §1.3, §12.3).
 */
public interface GuardProvider {
    /** A stable id for the integration, such as `mca`, used in logs. */
    public val id: String
}
