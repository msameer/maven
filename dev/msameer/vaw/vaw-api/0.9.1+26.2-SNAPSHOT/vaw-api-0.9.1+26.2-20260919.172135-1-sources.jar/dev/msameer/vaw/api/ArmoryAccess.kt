package dev.msameer.vaw.api

import net.minecraft.core.BlockPos
import net.minecraft.server.level.ServerLevel
import net.minecraft.world.item.ItemStack

/**
 * Village armories as a guard extension sees them (Technical Reference §12.2). Registered by the
 * core, which owns armories, their binding and which makers supply which guard type (§12.3); a
 * guard extension only reads and takes.
 */
public interface ArmoryAccess {
    /**
     * The armories within [range] blocks of [from] whose makers supply [guardType], nearest first.
     * [guardType] is the id a `vaw/guard_supplier` file names, such as `mca:guard`. Empty when no
     * such file names it, or when no guard provider is registered.
     */
    public fun armoriesFor(level: ServerLevel, guardType: String, from: BlockPos, range: Int): List<ArmoryView>
}

/** One armory: a maker's armory chest, or its armor stand (§11.7). Every read is of the world now. */
public interface ArmoryView {
    /** Where the armory is: the chest, or the stand's feet block. A guard takes from here. */
    public val pos: BlockPos

    /** What it holds now, as copies. */
    public fun contents(): List<ItemStack>

    /** Takes one item [wanted] accepts and returns it, or an empty stack when none is left (§12.2). */
    public fun takeOne(wanted: (ItemStack) -> Boolean): ItemStack
}
