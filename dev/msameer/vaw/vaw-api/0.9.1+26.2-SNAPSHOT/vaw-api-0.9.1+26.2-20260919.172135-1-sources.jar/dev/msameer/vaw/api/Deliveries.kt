package dev.msameer.vaw.api

import net.minecraft.core.BlockPos
import net.minecraft.server.level.ServerLevel
import net.minecraft.world.item.Item
import net.minecraft.world.item.ItemStack

/**
 * Shelf orders, for villagers the core does not drive: guards bringing in what they loot, and later
 * errand-running children (Technical Reference §7, §16.1). Registered by the core, which owns orders.
 */
public interface Deliveries {
    /**
     * Shelves within [range] blocks of [from] with an outstanding order for [item], in the order the
     * core's own producers serve them: shelves holding none of it first, then top-ups, at random
     * within each (§7.6).
     */
    public fun ordersFor(level: ServerLevel, item: Item, from: BlockPos, range: Int): List<ShelfOrder>
}

/** One shelf's order for one item. */
public interface ShelfOrder {
    /** The shelf to bring it to. */
    public val shelf: BlockPos

    /** How many it ordered when listed. [deliver] reads the shelf again. */
    public val count: Int

    /**
     * Moves as much of [stack] onto the shelf as it still orders now, shrinking [stack], and returns
     * how many went. The shelf is read again first, so an order another villager filled meanwhile is
     * never overfilled (§7.4).
     */
    public fun deliver(stack: ItemStack): Int
}
