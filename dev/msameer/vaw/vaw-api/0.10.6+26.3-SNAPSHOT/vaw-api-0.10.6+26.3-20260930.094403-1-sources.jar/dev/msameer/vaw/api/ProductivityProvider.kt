package dev.msameer.vaw.api

import net.minecraft.world.entity.npc.villager.Villager

/**
 * How readily one villager takes on work (Technical Reference §7.8, #70), for an extension whose
 * villagers differ in it: with MCA, a happy villager is keener than an unhappy one. The core's
 * `productivity`, or a profession's override, is the value for a villager of middling mood; without
 * a provider every villager has it.
 */
public fun interface ProductivityProvider {
    /**
     * [villager]'s productivity, given the [base] the configuration sets for its profession, or
     * `null` to leave it at [base]. The core keeps the answer between 0 and 1.
     */
    public fun productivity(villager: Villager, base: Double): Double?
}
