package dev.msameer.vaw.api

/** Where extensions plug into Villagers at Work (Technical Reference §1.5). */
public object VawApi {
    /** The namespace of every id this mod owns. */
    public const val NAMESPACE: String = "vaw"

    @Volatile
    private var guard: GuardProvider? = null

    @Volatile
    private var reserve: ReserveProvider? = null

    @Volatile
    private var armories: ArmoryAccess? = null

    @Volatile
    private var deliveries: Deliveries? = null

    /** The registered guard provider, or `null` when no guard extension is installed. */
    public val guardProvider: GuardProvider? get() = guard

    /** Village armories, for a guard extension (§12.2). Registered by the core jar. */
    public val armoryAccess: ArmoryAccess? get() = armories

    /** Shelf orders, for villagers the core does not drive (§16.1). Registered by the core jar. */
    public val delivery: Deliveries? get() = deliveries

    /** The registered reserve provider, or `null` when every villager keeps the default reserve (§16.1). */
    public val reserveProvider: ReserveProvider? get() = reserve

    /**
     * Registers the guard provider. Its presence switches on armories and the guard-only makers
     * (§12.3). Call it during mod initialization.
     */
    public fun registerGuardProvider(provider: GuardProvider) {
        synchronized(this) {
            val existing = guard
            check(existing == null) { "a guard provider is already registered: ${existing?.id}" }
            guard = provider
        }
    }

    /** Registers the reserve provider (§16.1). Call it during mod initialization. */
    public fun registerReserveProvider(provider: ReserveProvider) {
        synchronized(this) {
            check(reserve == null) { "a reserve provider is already registered" }
            reserve = provider
        }
    }

    /** Registered by the core jar. Extensions read [armoryAccess], they do not register one. */
    public fun registerArmoryAccess(access: ArmoryAccess) {
        synchronized(this) {
            check(armories == null) { "armory access is already registered" }
            armories = access
        }
    }

    /** Registered by the core jar. Extensions read [delivery], they do not register one. */
    public fun registerDeliveries(orders: Deliveries) {
        synchronized(this) {
            check(deliveries == null) { "deliveries are already registered" }
            deliveries = orders
        }
    }
}
