package dev.msameer.vaw.api

import net.minecraft.core.BlockPos
import net.minecraft.resources.Identifier
import net.minecraft.server.level.ServerLevel
import net.minecraft.world.entity.npc.villager.Villager

/**
 * The mod's advancements (Technical Reference §22), for an extension that grants its own: the MCA
 * extension's guard advancements sit in the core's tab. Registered by the core, which owns who earns
 * them: the world's owner, in single player only.
 */
public interface Advancements {
    /**
     * Awards [advancement] to the world's owner if it is loaded and not yet earned. When [actor] or
     * the villager [other] finds has a name, a chat line saying what they did comes first, from the
     * language key `advancements.<namespace>.<path>.line` with the two villagers as its arguments.
     * [other] is asked only when the advancement is really being earned.
     */
    public fun award(level: ServerLevel, advancement: Identifier, actor: Villager?, other: () -> Villager?)

    /** The villager working at [pos]: its workstation, its shelf, or its armory chest or stand. `null` when nobody is found. */
    public fun workerAt(level: ServerLevel, pos: BlockPos): Villager?
}
