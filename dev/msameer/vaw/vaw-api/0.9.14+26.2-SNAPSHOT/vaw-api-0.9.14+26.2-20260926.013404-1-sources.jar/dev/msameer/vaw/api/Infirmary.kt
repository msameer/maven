package dev.msameer.vaw.api

import net.minecraft.core.BlockPos
import net.minecraft.server.level.ServerLevel
import net.minecraft.world.entity.npc.villager.Villager

/**
 * The village infirmary (Technical Reference §11.11), for villagers the core does not drive: a guard
 * extension sends a hurt guard to drink before it gears up (§12.2). Registered by the core, which
 * owns brewing stands and decides which of them may be drunk from; an extension only asks and drinks.
 */
public interface Infirmary {
    /** Whether [villager] is hurt enough to go for a potion: at or below half of its maximum health. */
    public fun needsHealing(villager: Villager): Boolean

    /**
     * The nearest brewing stand within [range] blocks of [villager] that is bound to a cleric's shelf
     * and holds a potion that would heal it, or `null`. A player's own stand is never offered.
     */
    public fun standFor(level: ServerLevel, villager: Villager, range: Int): BlockPos?

    /**
     * Drinks one potion that would heal [villager] from the stand at [stand], if it is still bound
     * and still holds one, and puts the empty bottle in the villager's inventory. Returns whether it
     * drank. The villager must be within reach of the stand; the call does not walk it there.
     */
    public fun drink(level: ServerLevel, villager: Villager, stand: BlockPos): Boolean
}
