package dev.msameer.vaw.api

import net.minecraft.core.BlockPos

/**
 * A fisherman's line in the water (§2.5, §11.9): the [water] block its bobber floats on, and the game
 * tick its catch lands, [bite], when the bobber goes under. Only a picture of the fishing the core
 * already does, for the client jar to draw: no hook entity exists, since vanilla's needs a player.
 */
public data class FishingLine(val water: BlockPos, val bite: Long)
