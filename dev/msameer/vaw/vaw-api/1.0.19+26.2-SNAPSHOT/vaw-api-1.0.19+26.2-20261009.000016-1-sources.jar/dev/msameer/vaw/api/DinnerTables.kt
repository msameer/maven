package dev.msameer.vaw.api

import net.minecraft.core.BlockPos
import net.minecraft.server.level.ServerLevel
import net.minecraft.world.entity.npc.villager.Villager
import net.minecraft.world.item.ItemStack
import net.minecraft.world.level.block.state.BlockState

/**
 * Where a village's dinner tables are (Technical Reference §23). Registered by Villagers after Work,
 * which decides what a table is; More Villagers at Work's Chef reads it to cook a meal for each.
 */
public fun interface DinnerTables {
    /**
     * Every table surface within Villagers after Work's range of [around]: a block a meal stands on,
     * with a seat beside it, whether a meal stands on it now or not.
     */
    public fun surfaces(level: ServerLevel, around: BlockPos): List<BlockPos>
}

/**
 * Who sets a village's dinner tables, and where their meals wait (§23). Registered by More Villagers
 * at Work, whose Chef sets them from its cabinet; Villagers after Work drives the setting itself.
 */
public fun interface TableSetters {
    /** Where [villager] keeps the meals it sets the tables with, or `null` for a villager that sets none. */
    public fun mealsOf(villager: Villager): BlockPos?
}

/**
 * What one portion of a meal standing on a table is (§23): a serving of a feast, a slice of a pie.
 * Registered by More Villagers at Work, which knows the meals' mod; Villagers after Work eats it at the
 * table, and without an answer falls back on a cake's bite.
 */
public fun interface MealPortions {
    /** The food one bite or serving of [meal] is, or `null` when this provider does not know it. */
    public fun portion(meal: BlockState): ItemStack?
}
