package dev.msameer.vaw.api

import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry
import net.fabricmc.fabric.api.attachment.v1.AttachmentSyncPredicate
import net.fabricmc.fabric.api.attachment.v1.AttachmentType
import net.minecraft.resources.Identifier
import net.minecraft.world.item.ItemStack

/**
 * Data attachment types shared by the core and client jars (Technical Reference §4.1). Both jars
 * nest this api mod, so each type is registered under the same id on the server and the client.
 */
public object VawAttachments {
    /**
     * The tool a villager is working with: "I am using this". Never the equipment slot (§2.2).
     * Synced, so the optional client jar can draw it; vanilla clients never receive it.
     */
    public val WORKING_TOOL: AttachmentType<ItemStack> =
        AttachmentRegistry.create(Identifier.fromNamespaceAndPath(VawApi.NAMESPACE, "working_tool")) {
                builder: AttachmentRegistry.Builder<ItemStack> ->
            builder.persistent(ItemStack.OPTIONAL_CODEC)
                .syncWith(ItemStack.OPTIONAL_STREAM_CODEC, AttachmentSyncPredicate.all())
        }

    /**
     * What a villager holds in place of its working tool: the item it is taking to a shelf. Drawn
     * instead of [WORKING_TOOL] while present, and never the equipment slot either (§2.2). Only a
     * picture of what the villager carries, since the items themselves stay in its inventory, so it
     * is transient; synced like the working tool.
     */
    public val HELD_ITEM: AttachmentType<ItemStack> =
        AttachmentRegistry.create(Identifier.fromNamespaceAndPath(VawApi.NAMESPACE, "held_item")) {
                builder: AttachmentRegistry.Builder<ItemStack> ->
            builder.syncWith(ItemStack.OPTIONAL_STREAM_CODEC, AttachmentSyncPredicate.all())
        }

    /** Touching this object registers every type. Called during mod initialization on both sides. */
    internal fun init() {
        check(WORKING_TOOL.identifier().namespace == VawApi.NAMESPACE)
        check(HELD_ITEM.identifier().namespace == VawApi.NAMESPACE)
    }
}
