package dev.msameer.vaw.api

import net.minecraft.world.entity.npc.villager.Villager

/**
 * Who goes to school (Technical Reference §24, #75), for an extension whose villagers grow up in
 * stages: with MCA, children and teens go and babies and toddlers do not, and a villager the player
 * has told to stay, to follow or to do a chore is left alone. Without a provider a vanilla child, an
 * unemployed villager and a nitwit go. The core asks it during school hours (#193).
 */
public fun interface SchoolProvider {
    /** Whether [villager] goes to school, or `null` to leave it to the default. */
    public fun attends(villager: Villager): Boolean?
}
