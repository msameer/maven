package dev.msameer.vaw.api

import net.minecraft.world.entity.EntityType
import net.minecraft.world.entity.npc.villager.Villager

/** Where extensions plug into Villagers at Work (Technical Reference §1.5). */
public object VawApi {
    /** The namespace of every id this mod owns. */
    public const val NAMESPACE: String = "vaw"

    @Volatile
    private var guard: GuardProvider? = null

    @Volatile
    private var reserve: ReserveProvider? = null

    @Volatile
    private var armories: ArmoryAccess? = null

    @Volatile
    private var deliveries: Deliveries? = null

    @Volatile
    private var signals: SignalListener? = null

    @Volatile
    private var family: FamilyProvider? = null

    @Volatile
    private var infirmaries: Infirmary? = null

    @Volatile
    private var progress: Advancements? = null

    @Volatile
    private var productivity: ProductivityProvider? = null
    @Volatile
    private var keepBack: KeepBackProvider? = null
    @Volatile
    private var breeding: BreedingProvider? = null
    @Volatile
    private var diet: DietProvider? = null

    private var school: SchoolProvider? = null
    @Volatile
    private var bedtime: Boolean = false
    @Volatile
    private var tables: DinnerTables? = null
    @Volatile
    private var setters: TableSetters? = null
    @Volatile
    private var portions: MealPortions? = null
    @Volatile
    private var iconTypes: Set<EntityType<out Villager>> = emptySet()

    @Volatile
    private var swingTypes: Set<EntityType<out Villager>> = emptySet()

    @Volatile
    private var armourHeadwearTypes: Set<EntityType<out Villager>> = emptySet()

    /** The registered guard provider, or `null` when no guard extension is installed. */
    public val guardProvider: GuardProvider? get() = guard

    /** Village armories, for a guard extension (§12.2). Registered by the core jar. */
    public val armoryAccess: ArmoryAccess? get() = armories

    /** Shelf orders, for villagers the core does not drive (§16.1). Registered by the core jar. */
    public val delivery: Deliveries? get() = deliveries

    /** The registered signal listener, or `null` when no extension signals blocked villagers itself (§8.3). */
    public val signalListener: SignalListener? get() = signals

    /**
     * Villager types besides vanilla's that show the error icon (§2.2). The core draws it only for
     * `minecraft:villager` unless an extension adds its own types here.
     */
    public val errorIconTypes: Set<EntityType<out Villager>> get() = iconTypes

    /**
     * Villager types besides vanilla's that swing the tool they are using (§2.5). The core swings it
     * only for `minecraft:villager` unless an extension adds its own types here, since another mod's
     * villager may animate its arms its own way.
     */
    public val toolSwingTypes: Set<EntityType<out Villager>> get() = swingTypes

    /**
     * Villager types whose renderer draws a head item only as armour (§1.9): another mod's villager
     * with no `CustomHeadLayer`. A profession's headwear, the Chef's hat, carries its equipment asset
     * on these, so it is drawn as a helmet rather than not at all.
     */
    public val headwearAsArmourTypes: Set<EntityType<out Villager>> get() = armourHeadwearTypes

    /** The registered reserve provider, or `null` when every villager keeps the default reserve (§16.1). */
    public val reserveProvider: ReserveProvider? get() = reserve

    /** The registered productivity provider, or `null` when every villager has its profession's productivity (§7.8, #70). */
    public val productivityProvider: ProductivityProvider? get() = productivity

    /** The registered family provider, or `null` when a child runs errands for anyone nearby (§16.1). */
    public val familyProvider: FamilyProvider? get() = family

    /** The village infirmary, for villagers the core does not drive, such as guards (§11.11, §12.2). Registered by the core jar. */
    public val infirmary: Infirmary? get() = infirmaries

    /** The mod's advancements, for an extension that grants its own (§22). Registered by the core jar. */
    public val advancements: Advancements? get() = progress

    /** What villagers keep back from storage, or `null` when nothing is (§6.3). Registered by Villagers after Work (§23). */
    public val keepBackProvider: KeepBackProvider? get() = keepBack

    /** The registered diet provider, or `null` when every villager eats any food (§23, #80). */
    public val dietProvider: DietProvider? get() = diet

    /** The registered school provider, or `null` when the default says who goes to school (§24, #75). */
    public val schoolProvider: SchoolProvider? get() = school

    /** The registered breeding provider, or `null` when every pair breeds as vanilla villagers (§23). */
    public val breedingProvider: BreedingProvider? get() = breeding

    /**
     * Whether villagers breed only at bedtime (§23): true while Villagers after Work is installed with
     * its `bedtimeBreeding` on. An extension turns its own villagers' breeding off while it is.
     */
    public val bedtimeBreeding: Boolean get() = bedtime

    /** Where the dinner tables are, or `null` without Villagers after Work (§23). */
    public val dinnerTables: DinnerTables? get() = tables

    /** Who sets the dinner tables, or `null` without More Villagers at Work (§23). */
    public val tableSetters: TableSetters? get() = setters

    /** What a meal's portion is, or `null` without More Villagers at Work (§23). */
    public val mealPortions: MealPortions? get() = portions

    /**
     * Registers the guard provider. Its presence switches on armories and the guard-only makers
     * (§12.3). Call it during mod initialization.
     */
    public fun registerGuardProvider(provider: GuardProvider) {
        synchronized(this) {
            val existing = guard
            check(existing == null) { "a guard provider is already registered: ${existing?.id}" }
            guard = provider
        }
    }

    /** Registers the reserve provider (§16.1). Call it during mod initialization. */
    public fun registerReserveProvider(provider: ReserveProvider) {
        synchronized(this) {
            check(reserve == null) { "a reserve provider is already registered" }
            reserve = provider
        }
    }

    /** Registers the productivity provider (§7.8, #70). Call it during mod initialization. */
    public fun registerProductivityProvider(provider: ProductivityProvider) {
        synchronized(this) {
            check(productivity == null) { "a productivity provider is already registered" }
            productivity = provider
        }
    }

    /** Registers the family provider (§16.1). Call it during mod initialization. */
    public fun registerFamilyProvider(provider: FamilyProvider) {
        synchronized(this) {
            check(family == null) { "a family provider is already registered" }
            family = provider
        }
    }

    /** Registers what villagers keep back from storage (§6.3, §23). Call it during mod initialization. */
    public fun registerKeepBackProvider(provider: KeepBackProvider) {
        synchronized(this) {
            check(keepBack == null) { "a keep-back provider is already registered" }
            keepBack = provider
        }
    }

    /** Registers the diet provider (§23, #80). Call it during mod initialization. */
    public fun registerDietProvider(provider: DietProvider) {
        synchronized(this) {
            check(diet == null) { "a diet provider is already registered" }
            diet = provider
        }
    }

    /** Registers who goes to school (§24, #75). Call it during mod initialization. */
    public fun registerSchoolProvider(provider: SchoolProvider) {
        synchronized(this) {
            check(school == null) { "a school provider is already registered" }
            school = provider
        }
    }

    /** Registers the breeding provider (§23). Call it during mod initialization. */
    public fun registerBreedingProvider(provider: BreedingProvider) {
        synchronized(this) {
            check(breeding == null) { "a breeding provider is already registered" }
            breeding = provider
        }
    }

    /** Registers where the dinner tables are (§23). Called by Villagers after Work during mod initialization. */
    public fun registerDinnerTables(provider: DinnerTables) {
        synchronized(this) {
            check(tables == null) { "dinner tables are already registered" }
            tables = provider
        }
    }

    /** Registers who sets the dinner tables (§23). Call it during mod initialization. */
    public fun registerTableSetters(provider: TableSetters) {
        synchronized(this) {
            check(setters == null) { "table setters are already registered" }
            setters = provider
        }
    }

    /** Registers what a meal's portion is (§23). Call it during mod initialization. */
    public fun registerMealPortions(provider: MealPortions) {
        synchronized(this) {
            check(portions == null) { "meal portions are already registered" }
            portions = provider
        }
    }

    /** Says villagers breed only at bedtime (§23). Called by Villagers after Work during mod initialization. */
    public fun enableBedtimeBreeding() {
        bedtime = true
    }

    /** Registered by the core jar. Extensions read [armoryAccess], they do not register one. */
    public fun registerArmoryAccess(access: ArmoryAccess) {
        synchronized(this) {
            check(armories == null) { "armory access is already registered" }
            armories = access
        }
    }

    /** Registered by the core jar. Extensions read [advancements], they do not register them. */
    public fun registerAdvancements(access: Advancements) {
        synchronized(this) {
            check(progress == null) { "advancements are already registered" }
            progress = access
        }
    }

    /** Registered by the core jar. Extensions read [infirmary], they do not register one. */
    public fun registerInfirmary(access: Infirmary) {
        synchronized(this) {
            check(infirmaries == null) { "the infirmary is already registered" }
            infirmaries = access
        }
    }

    /** Registered by the core jar. Extensions read [delivery], they do not register one. */
    public fun registerDeliveries(orders: Deliveries) {
        synchronized(this) {
            check(deliveries == null) { "deliveries are already registered" }
            deliveries = orders
        }
    }

    /** Registers the signal listener (§8.3). Call it during mod initialization. */
    public fun registerSignalListener(listener: SignalListener) {
        synchronized(this) {
            check(signals == null) { "a signal listener is already registered" }
            signals = listener
        }
    }

    /** Has the core show the error icon on villagers of [type] too (§2.2). Call it during mod initialization. */
    public fun showErrorIconsFor(type: EntityType<out Villager>) {
        synchronized(this) { iconTypes = iconTypes + type }
    }

    /** Has the core swing the tool of villagers of [type] too as they use it (§2.5). Call it during mod initialization. */
    public fun swingToolsFor(type: EntityType<out Villager>) {
        synchronized(this) { swingTypes = swingTypes + type }
    }

    /** Has a profession's headwear drawn as armour on villagers of [type] (§1.9). Call it during mod initialization. */
    public fun wearsHeadwearAsArmourFor(type: EntityType<out Villager>) {
        synchronized(this) { armourHeadwearTypes = armourHeadwearTypes + type }
    }
}
