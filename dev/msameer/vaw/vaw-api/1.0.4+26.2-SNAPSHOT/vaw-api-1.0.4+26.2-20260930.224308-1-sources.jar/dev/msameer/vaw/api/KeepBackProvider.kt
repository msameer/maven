package dev.msameer.vaw.api

import net.minecraft.world.entity.npc.villager.Villager
import net.minecraft.world.item.Item

/**
 * Holds back part of what a villager would take to storage (Technical Reference §6.3, §23).
 * Registered by Villagers after Work, whose cooks keep an evening share of their food.
 *
 * Only storage gives way to it: the core serves every order before it asks, so a customer never
 * goes without what a villager is keeping back.
 */
public fun interface KeepBackProvider {
    /** How many of [item] [villager] keeps back from storage, or 0 for none. */
    public fun keepsBack(villager: Villager, item: Item): Int
}
